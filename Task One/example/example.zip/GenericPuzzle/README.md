# GenericPuzzle  

### Create a sliding block puzzle with any image  
![screenshot from 2016-12-03 14-06-58](https://cloud.githubusercontent.com/assets/6639323/20859553/44129f9c-b962-11e6-9f11-73954ba47e6c.png)
![screenshot from 2016-12-03 14-06-54](https://cloud.githubusercontent.com/assets/6639323/20859555/44151812-b962-11e6-93d3-87fc6417dafe.png)
![screenshot from 2016-12-03 14-01-00](https://cloud.githubusercontent.com/assets/6639323/20859556/4415ce42-b962-11e6-90b3-4fd5af3eb4af.png)
![screenshot from 2016-12-03 14-08-36](https://cloud.githubusercontent.com/assets/6639323/20859554/4412e2f4-b962-11e6-88de-d9a427edef6b.png)
