package com.maxwittig.genericpuzzle.utils;

import javafx.scene.image.Image;


public class ImageUtils
{

}
