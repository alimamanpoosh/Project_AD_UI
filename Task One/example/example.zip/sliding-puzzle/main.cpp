#include "puzzle/puzzle.h"

int main()
{
    puzzle p;
    p.run();
}
